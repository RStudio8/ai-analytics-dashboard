// AI-Powered Analytics Dashboard - Full Project as per ADmyBRAND Internship Task A
// Built using Next.js, TailwindCSS, Recharts, Framer Motion
// Showcases beautiful UI, reusable components, AI-simulated insights, and is ready for deployment

import { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from "framer-motion";

const mockData = [
  { date: '2025-07-01', users: 200, revenue: 1500 },
  { date: '2025-07-02', users: 300, revenue: 2000 },
  { date: '2025-07-03', users: 250, revenue: 1800 },
  { date: '2025-07-04', users: 400, revenue: 2200 },
  { date: '2025-07-05', users: 350, revenue: 2100 },
];

const InsightBox = ({ insight }: { insight: string }) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6 }}
    className="col-span-2"
  >
    <Card className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 text-white shadow-lg rounded-2xl">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold mb-2">💡 AI Insight</h2>
        <p className="text-md leading-relaxed">{insight}</p>
      </CardContent>
    </Card>
  </motion.div>
);

const MetricCard = ({ title, value, icon }: { title: string, value: string, icon: string }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.4 }}
  >
    <Card className="bg-white shadow-md rounded-xl p-4 hover:shadow-xl transition-all">
      <CardContent>
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm text-gray-500 font-medium">{title}</h2>
            <p className="text-2xl font-bold mt-1">{value}</p>
          </div>
          <div className="text-2xl">{icon}</div>
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

export default function Dashboard() {
  const [insight, setInsight] = useState("Analyzing metrics using AI algorithms...");

  useEffect(() => {
    // Simulate AI-generated insight using timeout
    setTimeout(() => {
      setInsight("🚀 Revenue saw a 17% jump this week, mainly from a 25% user spike on July 4th. Engagement levels peaked at 6 PM daily.");
    }, 1000);
  }, []);

  return (
    <main className="p-6 md:p-10 bg-gradient-to-tr from-gray-50 via-white to-gray-100 min-h-screen">
      <motion.h1
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
        className="text-3xl font-bold text-gray-800 mb-6"
      >
        📊 AI-Powered Analytics Dashboard
      </motion.h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard title="Total Users" value="1,500" icon="👥" />
        <MetricCard title="Monthly Revenue" value="$12,000" icon="💰" />
        <MetricCard title="Active Sessions" value="385" icon="📈" />
        <MetricCard title="Bounce Rate" value="34%" icon="🔄" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
          <Card className="shadow-md">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold text-gray-700 mb-4">📈 Users Over Time</h2>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={mockData}>
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="users" stroke="#4f46e5" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6 }}>
          <Card className="shadow-md">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold text-gray-700 mb-4">💵 Revenue Over Time</h2>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={mockData}>
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <InsightBox insight={insight} />
    </main>
  );
}
